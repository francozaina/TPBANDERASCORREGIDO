import './App.css';
import { useState, useEffect } from 'react';
import axios from 'axios';
import Juego from './Components/Juego';

function App() {
  const [respuesta, setRespuesta] = useState('');
  const [arrayPaises, setArrayPaises] = useState([]);
  const [puntos, setPuntos] = useState(0);
  const [pais, setPais] = useState({});
  const [timer, setTimer] = useState(15);
  const [referencia, setReferencia] = useState();
  const [stringLetras, setStringLetras] = useState('');
  const [ayudaUtilizada, setAyudaUtilizada] = useState(false);

  useEffect(() => {
    if (timer === 0 || timer < 0) {
      cambiarPais();
    }
  }, [timer]);

  useEffect(() => {
    axios
      .get('https://countriesnow.space/api/v0.1/countries/flag/images')
      .then((response) => {
        const array = response.data.data;
        let id = Math.floor(Math.random() * array.length);
        setPais(array[id]);
        setStringLetras(array[id].name);
        setArrayPaises(array);
      });
  }, []);

  useEffect(() => {
    if (respuesta === pais.name) {
      setPuntos((puntos) => puntos + 10 + timer);
      cambiarPais();
    } else {
      if (puntos > 0) setPuntos((puntos) => puntos - 1);
    }
  }, [respuesta]);

  let cambiarPais = () => {
    clearInterval(referencia);
    setTimer(15);
    if (!ayudaUtilizada) {
      setReferencia(setInterval(() => setTimer((t) => t - 1), 1000));
    }
    if (respuesta !== pais.name || ayudaUtilizada) {
      setPuntos((puntos) => puntos - 1);
    }
    let id = Math.floor(Math.random() * arrayPaises.length);
    setPais(arrayPaises[id]);
    setStringLetras(arrayPaises[id].name);
    setAyudaUtilizada(false);
    setRespuesta('');
  };

  return (
    <div className="App">
      <header className="App-header">
        <h2>Tiempo: {timer}</h2>
        <Juego
          setRespuesta={setRespuesta}
          flag={pais.flag}
          cambiarPais={cambiarPais}
          setAyudaUtilizada={setAyudaUtilizada}
        />
        <h1>Puntos: {puntos}</h1>
      </header>
    </div>
  );
}

export default App;